# Handoff: Virome City — Design System, Versión B

## Overview
Versión B es una dirección visual alternativa para "Virome City" (libro sobre análisis de viroma humano, metáfora de atlas de ciudad). Fría/científica en vez de cálida/editorial: fondo blanco de laboratorio, navy como tinta, y 4 acentos funcionales fijos por tipo de componente (no por capítulo/distrito).

## Fidelity
**High-fidelity.** Los valores abajo son finales — impleméntalos exactamente.

## Design Tokens

### Colores
| Token | Hex | Rol |
|---|---|---|
| `--bg-paper` | `#ffffff` | Fondo de página. Blanco de laboratorio, sin tinte cálido. |
| `--ink` | `#14213d` | Texto principal, headings, bordes de tarjeta con acento. |
| `--ink-soft` | `#5c6b82` | Texto secundario, captions, meta. |
| `--line` | `#e2e6ec` | Bordes de tarjeta, separadores. |
| `--structure` (Figure) | `#0891b2` | Acento de Figure/datos técnicos. |
| `--voice` (Question / Fivi note) | `#e85d4e` | Acento de Question y Fivi Note. |
| `--method` (Methodology tip) | `#d99a1b` | Acento de Methodology Tip. |
| `--insight` | `#6c63c9` | Acento de Insight (fondo tintado `#eef0fb`). |
| Research note | `#5c6b82` en borde punteado `#c7cdd7` | Neutro, sin acento de color. |

Regla: el color identifica el TIPO de componente y es fijo en cualquier capítulo — igual que en la versión A del sistema, solo cambia la paleta.

### Tipografía
- **Headings**: Space Grotesk, 600–700 (geométrico, técnico).
- **Cuerpo/etiquetas**: IBM Plex Sans, 400–700.
- **Técnico/mono**: IBM Plex Mono, 500.
- Google Fonts: `Space+Grotesk:wght@500;600;700` + `IBM+Plex+Sans:wght@400;500;600;700` + `IBM+Plex+Mono:wght@500`.

Escala:
- H1: 600 40px Space Grotesk
- Cuerpo: 400 18px/1.6 IBM Plex Sans
- Kicker/label: 700 11px IBM Plex Mono, letter-spacing 1.5px, uppercase
- Técnico: 500 14px IBM Plex Mono

### Espaciado y forma
- Mismas reglas de espaciado que la versión A: secciones abren con 80px de aire, Figuras con 48px antes/después, 32px de padding interno de componente, 24px entre párrafos.
- Border-radius 8px en tarjetas (más geométrico que la versión A, que usa 3–4px).
- Bordes sólidos 1px `--line`, más el acento como `border-left: 4px solid` en Question y Methodology tip.

## Componentes (6) — mismo set que la versión A, restilizado
1. **Question** — tarjeta blanca, borde izquierdo `--voice`, título Space Grotesk 600 24px.
2. **Figure** — tarjeta blanca, label mono `--structure`, placeholder con borde punteado, caption IBM Plex Sans.
3. **Insight** — fondo tintado `#eef0fb`, sin borde, label `--insight`.
4. **Fivi Note** — tarjeta blanca, ícono Fivi 52px + texto Space Grotesk 500 16px, label `--voice`.
5. **Methodology Tip** — borde izquierdo `--method`, cuerpo IBM Plex Sans.
6. **Research Note** — borde punteado neutro, sin fill, texto `--ink-soft`.

## Assets
- `Fivi.png`, `fivi-happy.png` — mascota (bacteriófago icosaédrico), usada en Fivi Notes.

## Archivo
- `Virome-City-Design-System-B.html` — la sección "Versión B" completa, aislada como archivo independiente para implementar solo esta dirección.
