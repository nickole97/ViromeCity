# Handoff: Virome City — Design System

## Overview
Design system for "Virome City," a non-fiction book/site guiding researchers through analyzing a human virome. The book is structured as a city atlas with 4 "districts" (chapters: What, Why, Where, How-to) plus a tool section ("Fivi's Kitchen"). This bundle defines the editorial visual language — palette, type, spacing, and 6 reusable content components — to apply consistently across all chapters.

## About the Design Files
The file in this bundle (`Virome-City-Design-System.html`) is a **design reference built in HTML** — a live style guide showing exact colors, type, spacing, and component treatments. It is not production code to copy directly. The task is to recreate this system in the target codebase's actual stack (the book currently publishes via **Quarto**, generating static HTML from `.qmd` files — see https://github.com/nickole97/ViromeCity). Recreate the tokens and component styles as Quarto/CSS partials (or React/whatever stack is chosen) that produce pixel-equivalent output, not a literal copy-paste of this file.

## Fidelity
**High-fidelity.** Colors, type sizes/weights, and spacing values in the reference file are final — implement them exactly, not as a rough guide.

## Visual concept
Editorial atlas metaphor: the book is a map of a microscopic "city," organized into 4 districts (chapters). Districts are **structural, not chromatic** — they do not carry their own color. Instead, color is assigned per **component type** and stays fixed across every chapter, so a reader learns "orange always means Figure" regardless of which chapter they're in.

## Design Tokens

### Colors
| Token | Hex | Role |
|---|---|---|
| `--bg-paper` | `#f6f1e4` | Page background — never pure white. |
| `--card-bg` | `#fdfbf5` | Component/card surfaces, slightly lighter than page. |
| `--ink` | `#241f1a` | Primary text, headings, line art. |
| `--ink-soft` | `#6b6259` | Captions, figure metadata, Research note text/border. |
| `--ink-secondary` | `#4a4239` | Secondary body copy (e.g. lede paragraphs). |
| `--line` | `#e4dcc8` | Dividers, card borders — never a closed box, just hairlines. |
| `--line-alt` | `#d8cdb2` | Alternate hairline/inset shadow tone. |
| `--component-question` / `--component-fivi` | `#a13d3d` (hover `#7c2e2e`) | Question component + Fivi Note voice. Also default link color. |
| `--component-figure` | `#d9752c` | Figure component accent (border, label, caption ink `#a3672f`). |
| `--component-insight` | `#2f6f6b` | Insight component accent + tinted background `#f2ece0`. |
| `--component-methodology` | `#d9a441` (label text `#a3792a`) | Methodology Tip accent. |
| `--component-research` | `#6b6259` | Research Note — neutral, dashed border `#d8cdb2`. |
| Figure placeholder stripe | `#f2e6d3` | Diagonal stripe pattern for unfinished figure art. |

Rule: color = component type, fixed everywhere. Never color-code by chapter/district.

### Typography
- **Headings (H1/H2) & "voice of the book"** (Question copy, Fivi Note body, italic emphasis): **Fraunces**, serif, weights 400–700, italic 500–600 for voice.
- **Body copy, labels, captions, UI chrome** (kickers, component labels, figure captions, Insight/Methodology/Research body text): **Nunito Sans**, weights 400–800.
- **Technical/taxonomic data** (ssRNA, dsDNA, virus family names): **JetBrains Mono**, weight 500.
- Google Fonts import: `Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;0,9..144,700;1,9..144,500;1,9..144,600` + `Nunito Sans:wght@400;500;600;700;800` + `JetBrains Mono:wght@500`.

Type scale (from the reference):
- Display/H1: 700 44px/1.1 Fraunces
- H2 section: 700 30px/1.15 Fraunces
- Body: 400 18px/1.6 Nunito Sans
- Voice/italic: italic 500 19px Fraunces
- Kicker: 800 12px Nunito Sans, letter-spacing 2.5px, uppercase
- Caption: 600 13px Nunito Sans

### Spacing
Base unit 8px.
- Section vertical padding: **80px** top/bottom (every major section opens with this much air).
- Figure margin: **48px** before and after, separating it from surrounding prose.
- Component internal padding: **32px**.
- Paragraph spacing: **24px**.

### Other
- Border radius: small, 3–4px on cards/figures — the system otherwise avoids boxes; most separation is whitespace + hairline (`--line`), not closed containers.
- Figures are always **line-art technical diagrams**, never photorealistic — ink on paper, single accent color max.
- Fivi (the mascot) only ever appears in the margin of a note, never inside a diagram.

## Components (6)
1. **Question** — opens a district/section; italic Fraunces, large (26px+), colored `--component-question`. Frames the question the section answers.
2. **Figure** — numbered technical diagram (e.g. "Figure 2.1"), bordered in `--component-figure`, always has a caption below in Nunito Sans. Placeholder art uses a diagonal-stripe pattern until real line-art is supplied.
3. **Insight** — a highlighted finding/synthesis inside the prose, tinted background `#f2ece0`, no border, no mascot voice, accent `--component-insight`.
4. **Fivi Note** — mascot speaks in first person from the margin; layout is icon (Fivi image, 56px) + italic Fraunces text; color fixed to `--component-fivi` regardless of chapter.
5. **Methodology Tip** — actionable workflow advice, left-border accent `--component-methodology`, body in Nunito Sans.
6. **Research Note** — a more formal/citable technical aside; dashed neutral border, no fill, muted ink text.

## Assets
- `Fivi.png`, `fivi-happy.png` — mascot artwork (icosahedral bacteriophage character), used in Fivi Notes and as a wayfinding figure. Sourced from the user's uploads; copy these into the target repo's asset folder (matches `assets/img/Fivi.png` in the existing Quarto site).
- No other custom illustration assets exist yet — all Figure diagrams in the live book (e.g. `virion-anatomy.svg`, `tree-of-life.svg`, genome-type SVGs) already exist in `assets/img/what/` in the ViromeCity repo and should be restyled to the new ink/line-art treatment, not redrawn from scratch, unless the user requests new art.

## Reference content
Component copy in the reference file is pulled from the live chapter "How should I think about viruses?" (`sections/what.html` in the ViromeCity repo) — real Figure captions, the tree-of-life Insight, and Fivi's "don't overlook this axis" note — so the components can be checked directly against real usage.

## Files
- `Virome-City-Design-System.html` — the full interactive style guide (palette, type, spacing, 6 components, all inline-styled, single file, opens directly in a browser).
- `Virome-City-Cover-Options.html` — earlier cover explorations (3 directions) kept for visual-language reference; not part of the token system itself.
